# Mermaid Starter Pack (Home ↔ Work)

This pack gives you a reusable **style contract** and several **starter diagrams** tuned for big, structured graphs (ELK layout), consistent colors, and semantic classes.

## Files
- `style_contract.mmd` — House init, theme variables, classDefs for semantics.
- `template_olog.mmd` — Blank olog scaffold for new diagrams.
- `entropy_exergy.mmd` — Expanded entropy/exergy mini-map.
- `resource_morphisms.mmd` — Resource transformations & monoidal structure.
- `systems_functors.mmd` — Network→Equations functor and system stitching.

## How to use
1) Open your Mermaid Live Editor (the `dist/` you served with Python).
2) Copy any file's contents into the left pane.
3) Edit titles/labels and grow the graph.
4) Keep the `style_contract.mmd` init block at the top of each diagram (or paste its `%%{init: ...}%%` into your diagram) for consistent styling.

Tip: For *very large* graphs, ELK helps avoid overlaps; it's already set as default in this pack.