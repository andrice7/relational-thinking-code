import{b as r}from"./BIHlP0gY.js";var e=4;function a(o){return r(o,e)}export{a as c};
