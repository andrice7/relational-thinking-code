import{t as i}from"./Djk6sq4f.js";var n=0;function u(r){var t=++n;return i(r)+t}export{u};
