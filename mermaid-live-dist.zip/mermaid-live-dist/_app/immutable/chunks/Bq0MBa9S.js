import{aj as o,ak as n}from"./CN-G9jgT.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};
