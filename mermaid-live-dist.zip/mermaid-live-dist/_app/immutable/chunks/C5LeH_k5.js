const s=globalThis.__sveltekit_192rrks?.base??"",a=globalThis.__sveltekit_192rrks?.assets??s;export{a,s as b};
