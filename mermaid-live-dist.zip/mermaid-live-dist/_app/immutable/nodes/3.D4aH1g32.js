import{_ as m}from"../chunks/kME9Dulz.js";export{m as component};
