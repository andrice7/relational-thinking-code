import{l as o,a as r}from"../chunks/DLsNKI72.js";export{o as load_css,r as start};
